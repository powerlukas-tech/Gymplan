// Vorbereitung für native Apps (Schritt später: npm i @capacitor/ios @capacitor/android)
export default { appId: 'de.gymplan.app', appName: 'GYMPLAN', webDir: 'dist' };
