# GYMPLAN – Etappe 1, Schritt 1 (Fundament)
## Installation / Start / Build
    npm install
    npm run dev        # http://localhost:5173
    npm run build      # Typprüfung + Produktions-Build nach dist/
    npm run preview    # Build testen (Service Worker/Offline funktionieren nur hier, nicht im dev-Modus)
## Enthalten
6 Themes, eigene Farben, Schriftgröße, Kontrast, Animationen (automatisch gespeichert) · IndexedDB mit user_id · JSON-Export/-Import mit Prüfung · Backup/Wiederherstellen · Reset nach Bestätigung · PWA (Manifest, Service Worker, Auto-Update) · Navigation · Capacitor-Konfiguration
## Schritt 2/3 zusätzlich
Fragebogen, Plangenerator, Übungsdatenbank, Plan-Bearbeitung, Dashboard, Kalender (abhaken, verschieben), Trainingsprotokoll, Fortschrittsdiagramme, persönliche Ziele.
## Noch nicht enthalten (Etappe 2)
Konten, Cloud-Sync, Freunde, Challenges, Apple Health/Health Connect, Lifesum. Die Daten tragen bereits eine user_id.
## (alt)
Dashboard-Inhalte, Kalender, Fortschritt (Schritt 3)
## Struktur
src/core Typen+Theme · src/db IndexedDB · src/state Einstellungen · src/pages Seiten · public Icon
## Manuelle Tests
Theme wechseln + neu laden · Export → Reset → Import · Backup → Reset → Wiederherstellen · build+preview → Flugmodus → Seite lädt · Handy: "Zum Home-Bildschirm"
## Hinweis
iOS bevorzugt PNG-Icons; vor Veröffentlichung 180/192/512-px-PNGs ergänzen.

## Weitere Tests
Fragebogen → Plan prüfen · Übung tauschen/entfernen, neu laden · Kalender: abhaken, rückgängig, verschieben, zurück · Training mit Gewichten protokollieren → Fortschritt-Diagramm · Ziel anlegen/ändern · Export → Reset → Import mit Plan und Historie
