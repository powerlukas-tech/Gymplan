import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { registerSW } from 'virtual:pwa-register';
import App from './App';
import { SettingsProvider } from './state/SettingsContext';
import './styles.css';
registerSW({ immediate: true });
createRoot(document.getElementById('root')!).render(<BrowserRouter><SettingsProvider><App /></SettingsProvider></BrowserRouter>);
