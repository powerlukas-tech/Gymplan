import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { defaultSettings, Settings } from '../core/types';
import { applyTheme } from '../core/theme';
import { getOne, put } from '../db/db';
const Ctx = createContext<{ s: Settings; update: (p: Partial<Settings>) => void; reload: () => Promise<void> }>(null as any);
export const useSettings = () => useContext(Ctx);
export function SettingsProvider({ children }: { children: ReactNode }) {
  const [s, setS] = useState<Settings>(defaultSettings);
  const [ready, setReady] = useState(false);
  const reload = async () => { const x = await getOne<Settings>('settings', 'main'); const v = { ...defaultSettings, ...x }; setS(v); applyTheme(v); };
  useEffect(() => { reload().finally(() => setReady(true)); }, []);
  const update = (p: Partial<Settings>) => {
    const v = { ...s, ...p, updatedAt: new Date().toISOString() };
    setS(v); applyTheme(v); put('settings', v); // automatisches Speichern
  };
  return ready ? <Ctx.Provider value={{ s, update, reload }}>{children}</Ctx.Provider> : null;
}
