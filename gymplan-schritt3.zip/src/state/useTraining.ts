import { useCallback, useEffect, useState } from 'react';
import { getAll, getOne } from '../db/db';
import type { Goal, Log, Move, Plan } from '../core/types';
export interface TData { plan: Plan | null; logs: Log[]; moves: Move[]; goals: Goal[] }
export function useTraining() {
  const [d, setD] = useState<TData | null>(null);
  const load = useCallback(async () => {
    const all = await getAll<any>('sessions');
    const g = await getOne<{ items: Goal[] }>('settings', 'goals');
    setD({ plan: (await getOne<Plan>('plans', 'active')) ?? null, logs: all.filter((x) => x.kind === 'log'), moves: all.filter((x) => x.kind === 'move'), goals: g?.items ?? [] });
  }, []);
  useEffect(() => { load(); }, [load]);
  return { d, load };
}
