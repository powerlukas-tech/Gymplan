import type { Settings, ThemeName } from './types';
export const THEMES: Record<Exclude<ThemeName, 'eigen'>, { label: string; accent: string; bg: string; light?: boolean }> = {
  gruen: { label: 'Schwarz-Grün', accent: '#3ddc84', bg: '#0b0d0c' },
  blau: { label: 'Schwarz-Blau', accent: '#4aa3ff', bg: '#0a0c10' },
  lila: { label: 'Schwarz-Lila', accent: '#b07cff', bg: '#0e0b12' },
  orange: { label: 'Schwarz-Orange', accent: '#ff9f43', bg: '#0f0c09' },
  rot: { label: 'Schwarz-Rot', accent: '#ff5d5d', bg: '#0f0a0a' },
  hell: { label: 'Hell', accent: '#12a150', bg: '#f4f6f5', light: true }
};
export function applyTheme(s: Settings) {
  const t: { accent: string; bg: string; light?: boolean } = s.theme === 'eigen' ? { accent: s.customAccent, bg: s.customBg } : THEMES[s.theme];
  const light = !!t.light, hi = s.contrast === 'hoch';
  const r = document.documentElement.style;
  r.setProperty('--accent', t.accent); r.setProperty('--bg', t.bg);
  r.setProperty('--card', light ? '#ffffff' : `color-mix(in srgb, ${t.bg} 88%, white)`);
  r.setProperty('--text', light ? (hi ? '#000' : '#16201b') : (hi ? '#fff' : '#e8efeb'));
  r.setProperty('--muted', light ? (hi ? '#222' : '#5b6761') : (hi ? '#d0d8d4' : '#8a9791'));
  r.setProperty('--line', light ? '#d5dcd8' : (hi ? '#5a6560' : '#26302b'));
  r.fontSize = (16 * s.fontSize) / 100 + 'px';
  document.documentElement.dataset.anim = s.animations ? 'on' : 'off';
  document.querySelector('meta[name=theme-color]')?.setAttribute('content', t.bg);
}
