import type { Log, Move, Plan, PlanDay } from './types';
import { LOCAL_USER_ID } from './types';
import { byId } from './exercises';
import { estMinutes } from './planner';
export const key = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
export const parse = (k: string) => new Date(k + 'T00:00:00');
export const addDays = (k: string, n: number) => { const d = parse(k); d.setDate(d.getDate() + n); return key(d); };
export const weekday = (k: string) => (parse(k).getDay() + 6) % 7;
export const fmt = (k: string) => parse(k).toLocaleDateString('de-DE', { weekday: 'short', day: 'numeric', month: 'short' });
export interface Occ { day: PlanDay; orig: string; date: string; moved: boolean; log?: Log }
export function occOn(plan: Plan, moves: Move[], logs: Log[], date: string): Occ[] {
  const start = key(new Date(plan.createdAt)), w = weekday(date), res: Occ[] = [];
  for (const day of plan.days)
    if (day.weekday === w && date >= start && !moves.some((m) => m.dayId === day.id && m.from === date)) res.push({ day, orig: date, date, moved: false });
  for (const m of moves) if (m.to === date) { const day = plan.days.find((x) => x.id === m.dayId); if (day) res.push({ day, orig: m.from, date, moved: true }); }
  return res.map((o) => ({ ...o, log: logs.find((l) => l.id === `log_${o.orig}_${o.day.id}`) }));
}
export function defaultLog(o: Occ, date: string): Log {
  return {
    id: `log_${o.orig}_${o.day.id}`, kind: 'log', user_id: LOCAL_USER_ID, origDate: o.orig, dayId: o.day.id, date, label: o.day.label,
    durationMin: estMinutes(o.day.exercises), notes: '',
    entries: o.day.exercises.map((e) => ({ exId: e.exId, name: byId(e.exId)?.name || e.exId, sets: Array.from({ length: e.sets }, () => ({ reps: parseInt(e.reps) || 0, weight: 0 })) }))
  };
}
