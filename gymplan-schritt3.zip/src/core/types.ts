export const LOCAL_USER_ID = 'local'; // Etappe 2: durch echte Konto-ID ersetzen
export type ThemeName = 'gruen' | 'blau' | 'lila' | 'orange' | 'rot' | 'hell' | 'eigen';
export interface Settings {
  id: 'main'; user_id: string; theme: ThemeName;
  customAccent: string; customBg: string;
  fontSize: number; contrast: 'normal' | 'hoch'; animations: boolean; updatedAt: string;
}
export const defaultSettings: Settings = {
  id: 'main', user_id: LOCAL_USER_ID, theme: 'gruen', customAccent: '#3ddc84', customBg: '#0b0d0c',
  fontSize: 100, contrast: 'normal', animations: true, updatedAt: new Date().toISOString()
};
export type Answers = Record<string, string | string[]>;
export interface PlanExercise { uid: string; exId: string; sets: number; reps: string; rest: number }
export interface PlanDay { id: string; weekday: number; label: string; exercises: PlanExercise[] }
export interface Plan { id: 'active'; user_id: string; createdAt: string; answers: Answers; weeks: number; notes: string[]; days: PlanDay[] }
export interface LogSet { reps: number; weight: number }
export interface LogEntry { exId: string; name: string; sets: LogSet[] }
export interface Log { id: string; kind: 'log'; user_id: string; origDate: string; dayId: string; date: string; label: string; durationMin: number; notes: string; entries: LogEntry[] }
export interface Move { id: string; kind: 'move'; user_id: string; from: string; to: string; dayId: string }
export interface Goal { id: string; title: string; current: number; target: number; unit: string }
