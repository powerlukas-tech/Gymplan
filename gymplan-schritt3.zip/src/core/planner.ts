import { Answers, LOCAL_USER_ID, Plan, PlanDay, PlanExercise } from './types';
import { EX, Exercise } from './exercises';
const arr = (v: unknown): string[] => (Array.isArray(v) ? v : v ? [String(v)] : []);
export const WD = ['Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag', 'Sonntag'];
export const LABEL: Record<string, string> = { ganz: 'Ganzkörper', ober: 'Oberkörper', unter: 'Unterkörper', push: 'Drücken', pull: 'Ziehen', beine: 'Beine', ausdauer: 'Ausdauer', beweglichkeit: 'Beweglichkeit' };
const T: Record<string, string[]> = {
  ganz: ['squat', 'push', 'pull', 'hinge', 'core'], ober: ['push', 'pull', 'push', 'pull', 'core'], unter: ['squat', 'hinge', 'lunge', 'core'],
  push: ['push', 'push', 'push', 'core'], pull: ['pull', 'pull', 'pull', 'core'], beine: ['squat', 'hinge', 'lunge', 'core'],
  ausdauer: ['cardio', 'cardio', 'core'], beweglichkeit: ['mobility', 'mobility', 'mobility', 'mobility']
};
const SLOTS: Record<number, number[]> = { 2: [0, 3], 3: [0, 2, 4], 4: [0, 1, 3, 4], 5: [0, 1, 2, 4, 5], 6: [0, 1, 2, 3, 4, 5] };
export function estMinutes(l: PlanExercise[]) {
  return Math.round(5 + l.reduce((m, e) => m + (/min/.test(e.reps) ? parseInt(e.reps) || 0 : (e.sets * (40 + e.rest)) / 60), 0));
}
export function generatePlan(a: Answers): Plan {
  const notes: string[] = [];
  const lv = ({ anfaenger: 1, mittel: 2, fortgeschritten: 3 } as Record<string, number>)[a.erfahrung as string] ?? 1;
  const dirs = arr(a.richtung);
  const strength = dirs.some((d) => ['muskel', 'kraft', 'fitness', 'calisthenics'].includes(d));
  let n = parseInt(a.tage as string) || 3;
  const cap = Math.min(lv === 1 ? 4 : lv === 2 ? 5 : 6, a.ruhe === 'we' ? 5 : 6);
  if (n > cap) { notes.push(`Deine ${n} Trainingstage wurden auf ${cap} begrenzt, damit genug Erholung bleibt.`); n = cap; }
  const have = new Set<string>(a.ort === 'gym' ? ['langhantel', 'kurzhanteln', 'klimmzugstange', 'barren', 'bank', 'maschinen', 'band'] : [...arr(a.geraete), ...(a.ort === 'draussen' ? ['klimmzugstange', 'barren'] : [])]);
  const ok = (e: Exercise) => e.level <= lv && e.equip.every((q) => have.has(q)) && !e.tags.some((t) => excl.has(t));
  const excl = new Set(arr(a.nicht)), pref = arr(a.bevorzugt), used = new Map<string, number>();
  const cat = dirs.includes('calisthenics') ? 'calisthenics' : 'kraft';
  let ty: string[];
  if (!strength) ty = Array.from({ length: n }, (_, i) => (dirs.includes('ausdauer') && (!dirs.includes('beweglichkeit') || i % 2 === 0) ? 'ausdauer' : 'beweglichkeit'));
  else {
    const sp = a.split && a.split !== 'auto' ? a.split : n <= 3 ? 'ganz' : n === 4 ? 'oberunter' : 'ppl';
    ty = Array.from({ length: n }, (_, i) => (sp === 'ganz' ? 'ganz' : sp === 'oberunter' ? (i % 2 ? 'unter' : 'ober') : ['push', 'pull', 'beine', 'push', 'pull', 'beine'][i]));
    if (dirs.includes('ausdauer') && n >= 3) ty[n - 1] = 'ausdauer';
  }
  const sl = a.ruhe === 'we' && n === 5 ? [0, 1, 2, 3, 4] : SLOTS[n] || [0, 2, 4];
  const sc = (e: Exercise) => (pref.includes(e.id) ? 6 : 0) + (e.cat === cat ? 2 : 0) + (e.level === lv ? 1 : 0) - 2 * (used.get(e.id) || 0);
  const pick = (p: string, seen: Set<string>) => EX.filter((e) => e.pattern === p && ok(e) && !seen.has(e.id)).sort((x, y) => sc(y) - sc(x))[0];
  const skillEx = (s: string) => {
    const c = EX.filter((e) => e.skill === s && ok(e)).sort((x, y) => y.level - x.level)[0];
    if (!c) notes.push(`Für „${s}“ fehlt noch Equipment oder die Grundkraft. Sie wird eingebaut, sobald die Voraussetzungen passen.`);
    return c;
  };
  const rx = (e: Exercise): PlanExercise => {
    let sets = 3, reps = '10–15', rest = 60;
    const heavy = ['squat', 'hinge', 'push', 'pull', 'lunge'].includes(e.pattern);
    if (e.pattern === 'cardio') { sets = 1; reps = e.t || '20 min'; rest = 0; }
    else if (e.pattern === 'mobility') { sets = 2; reps = e.t || '45 s'; rest = 15; }
    else if (e.t) { reps = e.t; rest = e.pattern === 'skill' ? 90 : 45; }
    else if (heavy && a.ziel === 'kraft') { sets = lv === 1 ? 3 : 4; reps = lv === 1 ? '6–8' : '4–6'; rest = 150; }
    else if (heavy && a.ziel === 'muskel') { sets = lv === 1 ? 3 : 4; reps = '8–12'; rest = 75; }
    return { uid: crypto.randomUUID(), exId: e.id, sets, reps, rest };
  };
  const sk = arr(a.skills).slice(0, 3);
  if (arr(a.skills).length > 3) notes.push('Maximal 3 Skills gleichzeitig, damit Technik und Erholung nicht leiden.');
  if (sk.some((s) => ['flag', 'planche', 'handstand'].includes(s))) notes.push('Human Flag, Planche und Handstand sind Langzeitziele: Fortschritt über Monate, nur saubere Ausführung, keine Maximalversuche.');
  const m = Math.min(7, Math.max(3, Math.round((parseInt(a.dauer as string) || 45) / 10)));
  const sd = ty.map((x, j) => (['ausdauer', 'beweglichkeit'].includes(x) ? -1 : j)).filter((j) => j >= 0);
  const days: PlanDay[] = ty.map((t, i) => {
    const seen = new Set<string>(), list: PlanExercise[] = [];
    const add = (e?: Exercise) => { if (!e || seen.has(e.id)) return; seen.add(e.id); used.set(e.id, (used.get(e.id) || 0) + 1); list.push(rx(e)); };
    sk.forEach((s, k) => { if (sd.length && (sd[k % sd.length] === i || (n >= 3 && sd[(k + 1) % sd.length] === i))) add(skillEx(s)); });
    const base = T[t], cnt = sd.includes(i) ? Math.max(1, m - list.length) : base.length;
    Array.from({ length: cnt }, (_, k) => base[k % base.length]).forEach((p) => add(pick(p, seen)));
    if (dirs.includes('beweglichkeit') && t !== 'beweglichkeit') add(pick('mobility', seen));
    return { id: crypto.randomUUID(), weekday: sl[i], label: LABEL[t], exercises: list };
  });
  notes.push('Steigerung: Schaffst du alle Sätze sauber am oberen Ende der Wiederholungen, erhöhe zuerst die Wiederholungen, dann das Gewicht (ca. 5 %). Plane etwa alle 4 Wochen eine leichtere Woche ein.');
  return { id: 'active', user_id: LOCAL_USER_ID, createdAt: new Date().toISOString(), answers: a, weeks: parseInt(a.zeit as string) || 12, notes: [...new Set(notes)], days };
}
