import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Plan, PlanDay, PlanExercise } from '../core/types';
import { EX, byId } from '../core/exercises';
import { WD, estMinutes } from '../core/planner';
import { getOne, put } from '../db/db';
export default function PlanPage() {
  const nav = useNavigate();
  const [p, setP] = useState<Plan | null | undefined>();
  useEffect(() => { getOne<Plan>('plans', 'active').then((x) => setP(x ?? null)); }, []);
  if (p === undefined) return null;
  if (!p) return <section><h1>Trainingsplan</h1><div className="card"><p>Du hast noch keinen Plan.</p><Link className="btn" to="/fragebogen">Fragebogen starten</Link></div></section>;
  const save = (n: Plan) => { setP(n); put('plans', n); };
  const mod = (d: PlanDay, f: (l: PlanExercise[]) => PlanExercise[]) => save({ ...p, days: p.days.map((x) => (x.id !== d.id ? x : { ...x, exercises: f(x.exercises) })) });
  const upd = (d: PlanDay, u: string, patch: Partial<PlanExercise>) => mod(d, (l) => l.map((e) => (e.uid === u ? { ...e, ...patch } : e)));
  const setDay = (d: PlanDay, wd: number) => save({ ...p, days: p.days.map((x) => (x.id === d.id ? { ...x, weekday: wd } : x)) });
  const free = WD.filter((_, i) => !p.days.some((d) => d.weekday === i));
  const days = [...p.days].sort((x, y) => x.weekday - y.weekday);
  return <section><h1>Trainingsplan</h1>
    <p className="muted">{p.days.length} Trainingstage pro Woche · Ziel in {p.weeks} Wochen · Ruhetage: {free.join(', ') || 'keine'}</p>
    {p.notes.map((n, i) => <p key={i} className="card note">{n}</p>)}
    {days.map((d) => <div className="card" key={d.id}>
      <h2>{d.label} · ca. {estMinutes(d.exercises)} Min.</h2>
      <label className="row">Wochentag<select value={d.weekday} onChange={(e) => setDay(d, +e.target.value)}>{WD.map((w, i) => <option key={w} value={i}>{w}</option>)}</select></label>
      <p className="muted">{[...new Set(d.exercises.flatMap((e) => byId(e.exId)?.areas || []))].join(', ')}</p>
      {d.exercises.map((e) => { const x = byId(e.exId); if (!x) return null; return <details key={e.uid} className="ex">
        <summary>{x.name} <span className="muted">{e.sets}× {e.reps} · {e.rest} s Pause</span></summary>
        <p>{x.desc}</p><p className="muted">Hinweis: {x.tip}</p>
        <div className="grid3">
          <label>Sätze<input type="number" min={1} max={8} value={e.sets} onChange={(ev) => upd(d, e.uid, { sets: Math.max(1, Math.min(8, +ev.target.value || 1)) })} /></label>
          <label>Wdh./Zeit<input value={e.reps} onChange={(ev) => upd(d, e.uid, { reps: ev.target.value })} /></label>
          <label>Pause (s)<input type="number" min={0} max={300} step={15} value={e.rest} onChange={(ev) => upd(d, e.uid, { rest: Math.max(0, Math.min(300, +ev.target.value || 0)) })} /></label></div>
        <label className="row">Alternative<select value="" onChange={(ev) => { const a = byId(ev.target.value); if (a) upd(d, e.uid, { exId: a.id, reps: a.t || e.reps }); }}>
          <option value="">Tauschen gegen …</option>{x.alts.map(byId).filter(Boolean).map((a) => <option key={a!.id} value={a!.id}>{a!.name}</option>)}</select></label>
        <button className="btn danger" onClick={() => mod(d, (l) => l.filter((y) => y.uid !== e.uid))}>Übung entfernen</button></details>; })}
      <label className="row">Übung hinzufügen<select value="" onChange={(ev) => { const a = byId(ev.target.value); if (a) mod(d, (l) => [...l, { uid: crypto.randomUUID(), exId: a.id, sets: 3, reps: a.t || '10–12', rest: 60 }]); }}>
        <option value="">Auswählen …</option>{EX.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}</select></label>
    </div>)}
    <button className="btn" onClick={() => { if (confirm('Der aktuelle Plan wird ersetzt, sobald du den Fragebogen abschließt. Fortfahren?')) nav('/fragebogen'); }}>Plan neu erstellen</button></section>;
}
