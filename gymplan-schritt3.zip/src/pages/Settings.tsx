import { useRef, useState } from 'react';
import { useSettings } from '../state/SettingsContext';
import { THEMES } from '../core/theme';
import { createBackup, exportAll, importAll, resetAll, restoreBackup, validateDump } from '../db/db';
export default function Settings() {
  const { s, update, reload } = useSettings();
  const [msg, setMsg] = useState(''); const file = useRef<HTMLInputElement>(null);
  const done = async (m: string) => { await reload(); setMsg(m); };
  const doExport = async () => {
    const blob = new Blob([JSON.stringify(await exportAll(), null, 2)], { type: 'application/json' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
    a.download = `gymplan-${new Date().toISOString().slice(0, 10)}.json`; a.click(); URL.revokeObjectURL(a.href); setMsg('Export gespeichert.');
  };
  const doImport = async (f?: File) => {
    if (!f) return;
    try {
      const d = JSON.parse(await f.text());
      if (!validateDump(d)) return setMsg('Import abgebrochen: Datei ist keine gültige GYMPLAN-Sicherung.');
      if (!confirm('Aktuelle Daten werden durch die Datei ersetzt. Fortfahren?')) return;
      await importAll(d); await done('Import abgeschlossen.');
    } catch { setMsg('Import abgebrochen: Datei konnte nicht gelesen werden.'); }
    if (file.current) file.current.value = '';
  };
  const keys = Object.keys(THEMES) as (keyof typeof THEMES)[];
  return <section><h1>Profil und Einstellungen</h1>
    <div className="card"><h2>Design</h2>
      <div className="chips">{keys.map(k => <button key={k} className={'chip' + (s.theme === k ? ' on' : '')} onClick={() => update({ theme: k })}>{THEMES[k].label}</button>)}
        <button className={'chip' + (s.theme === 'eigen' ? ' on' : '')} onClick={() => update({ theme: 'eigen' })}>Eigene Farben</button></div>
      {s.theme === 'eigen' && <div className="row"><label>Akzent <input type="color" value={s.customAccent} onChange={e => update({ customAccent: e.target.value })} /></label>
        <label>Hintergrund <input type="color" value={s.customBg} onChange={e => update({ customBg: e.target.value })} /></label></div>}
      <label className="row">Schriftgröße {s.fontSize}%<input type="range" min={85} max={130} step={5} value={s.fontSize} onChange={e => update({ fontSize: +e.target.value })} /></label>
      <label className="row">Hoher Kontrast <input type="checkbox" checked={s.contrast === 'hoch'} onChange={e => update({ contrast: e.target.checked ? 'hoch' : 'normal' })} /></label>
      <label className="row">Animationen <input type="checkbox" checked={s.animations} onChange={e => update({ animations: e.target.checked })} /></label></div>
    <div className="card"><h2>Daten</h2><p className="muted">Alles wird lokal auf diesem Gerät gespeichert.</p>
      <div className="chips">
        <button className="btn" onClick={doExport}>Als JSON exportieren</button>
        <button className="btn" onClick={() => file.current?.click()}>JSON importieren</button>
        <button className="btn" onClick={async () => setMsg('Backup erstellt: ' + new Date(await createBackup()).toLocaleString('de-DE'))}>Backup erstellen</button>
        <button className="btn" onClick={async () => { if (!confirm('Daten aus dem letzten Backup wiederherstellen?')) return; (await restoreBackup()) ? await done('Backup wiederhergestellt.') : setMsg('Kein Backup vorhanden.'); }}>Backup wiederherstellen</button>
        <button className="btn danger" onClick={async () => { if (!confirm('Wirklich ALLE Daten löschen? Das kann nicht rückgängig gemacht werden.')) return; await resetAll(); await done('Alle Daten wurden zurückgesetzt.'); }}>Daten zurücksetzen</button></div>
      <input ref={file} type="file" accept="application/json" hidden onChange={e => doImport(e.target.files?.[0])} />
      {msg && <p role="status" className="msg">{msg}</p>}</div></section>;
}
