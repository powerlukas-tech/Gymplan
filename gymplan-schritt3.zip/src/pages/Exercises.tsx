import { useState } from 'react';
import { EX } from '../core/exercises';
const LV = ['', 'Leicht', 'Mittel', 'Schwer'];
const CAT: Record<string, string> = { kraft: 'Kraft', calisthenics: 'Calisthenics', ausdauer: 'Ausdauer', beweglichkeit: 'Beweglichkeit' };
export default function Exercises() {
  const [q, setQ] = useState(''); const [c, setC] = useState(''); const [l, setL] = useState(0);
  const list = EX.filter((e) => (!c || e.cat === c) && (!l || e.level === l) && (e.name + e.areas.join(' ') + e.equip.join(' ')).toLowerCase().includes(q.toLowerCase()));
  const nm = (id: string) => EX.find((e) => e.id === id)?.name;
  return <section><h1>Übungen</h1>
    <input type="search" placeholder="Name, Muskelgruppe oder Gerät suchen" value={q} onChange={(e) => setQ(e.target.value)} />
    <div className="chips">{['', ...Object.keys(CAT)].map((k) => <button key={k} className={'chip' + (c === k ? ' on' : '')} onClick={() => setC(k)}>{k ? CAT[k] : 'Alle'}</button>)}</div>
    <div className="chips">{[0, 1, 2, 3].map((k) => <button key={k} className={'chip' + (l === k ? ' on' : '')} onClick={() => setL(k)}>{k ? LV[k] : 'Alle Stufen'}</button>)}</div>
    {list.length === 0 && <p className="muted">Keine Übung gefunden. Ändere Suche oder Filter.</p>}
    {list.map((e) => <details key={e.id} className="card ex"><summary>{e.name} <span className="muted">{LV[e.level]} · {CAT[e.cat]}</span></summary>
      <p>{e.desc}</p><p><b>Trainingsbereiche:</b> {e.areas.join(', ')}</p><p><b>Geräte:</b> {e.equip.join(', ') || 'keine'}</p>
      <p className="muted">Hinweis: {e.tip}</p><p><b>Alternativen:</b> {e.alts.map(nm).filter(Boolean).join(', ')}</p></details>)}</section>;
}
