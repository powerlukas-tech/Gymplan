import { Link } from 'react-router-dom';
import { addDays, fmt, key, occOn, weekday } from '../core/schedule';
import { useTraining } from '../state/useTraining';
export default function Dashboard() {
  const { d } = useTraining();
  if (!d) return null;
  const { plan, logs, moves, goals } = d, today = key(new Date());
  const occ = (k: string) => (plan ? occOn(plan, moves, logs, k) : []);
  const now = occ(today);
  let next: { k: string; label: string } | null = null;
  for (let i = 1; i <= 28 && !next; i++) { const o = occ(addDays(today, i))[0]; if (o) next = { k: addDays(today, i), label: o.day.label }; }
  const ws = addDays(today, -weekday(today)), week = Array.from({ length: 7 }, (_, i) => addDays(ws, i));
  const wk = week.flatMap(occ), done = wk.filter((o) => o.log).length;
  return <section><h1>GYMPLAN</h1><p className="muted">{fmt(today)}</p>
    {!plan && <div className="card"><h2>Kein Trainingsplan</h2><p>Beantworte ein paar Fragen, dann erstellt GYMPLAN deinen Plan.</p><Link className="btn on" to="/fragebogen">Fragebogen starten</Link></div>}
    {plan && <div className="card"><h2>Heute</h2>
      {!now.length && <p>Ruhetag. Erholung gehört zum Training.</p>}
      {now.map((o) => <p key={o.day.id}><b>{o.day.label}</b> · {o.day.exercises.length} Übungen · {o.log ? 'erledigt' : <Link className="btn on" to={`/training/${o.orig}/${o.day.id}`}>Training starten</Link>}</p>)}
      {next && <p className="muted">Nächstes Training: {fmt(next.k)}, {next.label}</p>}</div>}
    {plan && <div className="card"><h2>Diese Woche: {done} von {wk.length} erledigt</h2><div className="bar"><div style={{ width: (wk.length ? (done / wk.length) * 100 : 0) + '%' }} /></div>
      <div className="week">{week.map((k) => { const o = occ(k); const st = !o.length ? 'rest' : o.every((x) => x.log) ? 'done' : k < today ? 'missed' : 'plan';
        return <Link key={k} to="/kalender" className={'wd ' + st + (k === today ? ' today' : '')}><span>{['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'][weekday(k)]}</span><small>{o[0]?.day.label.slice(0, 5) || '–'}</small></Link>; })}</div></div>}
    <div className="stats"><div className="card stat"><b>{logs.length}</b><span className="muted">Einheiten gesamt</span></div>
      <div className="card stat"><b>{logs.reduce((s, l) => s + l.durationMin, 0)}</b><span className="muted">Minuten</span></div>
      <div className="card stat"><b>{logs.reduce((s, l) => s + l.entries.reduce((a, e) => a + e.sets.length, 0), 0)}</b><span className="muted">Sätze</span></div></div>
    <div className="card"><h2>Aktuelle Ziele</h2>{!goals.length && <p className="muted">Lege Ziele unter Fortschritt an.</p>}
      {goals.slice(0, 3).map((x) => <div key={x.id}><p>{x.title}: {x.current} von {x.target} {x.unit}</p><div className="bar"><div style={{ width: Math.min(100, (x.current / x.target) * 100) + '%' }} /></div></div>)}
      <Link className="btn" to="/fortschritt">Fortschritt ansehen</Link></div></section>;
}
