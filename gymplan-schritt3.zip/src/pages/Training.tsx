import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Log } from '../core/types';
import { defaultLog, fmt, key } from '../core/schedule';
import { put, remove } from '../db/db';
import { useTraining } from '../state/useTraining';
export default function Training() {
  const { orig = '', dayId = '' } = useParams(); const nav = useNavigate(); const { d } = useTraining();
  const [log, setLog] = useState<Log | null>(null); const [exists, setExists] = useState(false);
  useEffect(() => {
    if (!d?.plan) return;
    const day = d.plan.days.find((x) => x.id === dayId); if (!day) return;
    const old = d.logs.find((l) => l.id === `log_${orig}_${dayId}`); setExists(!!old);
    const today = key(new Date());
    setLog(old ?? defaultLog({ day, orig, date: orig, moved: false }, orig <= today ? orig : today));
  }, [d]);
  if (!d) return null;
  if (!log) return <section><h1>Training</h1><p>Diese Einheit gehört nicht (mehr) zum aktuellen Plan.</p></section>;
  const num = (v: string) => Math.max(0, +v || 0);
  const setVal = (ei: number, si: number, p: Partial<{ reps: number; weight: number }>) => setLog({ ...log, entries: log.entries.map((e, i) => i !== ei ? e : { ...e, sets: e.sets.map((s, j) => j === si ? { ...s, ...p } : s) }) });
  const addSet = (ei: number, delta: 1 | -1) => setLog({ ...log, entries: log.entries.map((e, i) => i !== ei ? e : { ...e, sets: delta > 0 ? [...e.sets, { ...e.sets[e.sets.length - 1] || { reps: 0, weight: 0 } }] : e.sets.slice(0, -1) }) });
  return <section><h1>{log.label}</h1><p className="muted">{fmt(orig)}</p>
    {log.entries.map((e, ei) => <div className="card" key={ei}><h2>{e.name}</h2>
      {e.sets.map((s, si) => <div className="setrow" key={si}><span>Satz {si + 1}</span>
        <label>Wdh./Sek.<input type="number" min={0} value={s.reps} onChange={(ev) => setVal(ei, si, { reps: num(ev.target.value) })} /></label>
        <label>kg<input type="number" min={0} step={0.5} value={s.weight} onChange={(ev) => setVal(ei, si, { weight: num(ev.target.value) })} /></label></div>)}
      <div className="chips"><button className="btn" onClick={() => addSet(ei, 1)}>Satz hinzufügen</button><button className="btn" disabled={e.sets.length <= 1} onClick={() => addSet(ei, -1)}>Satz entfernen</button></div></div>)}
    <div className="card"><label className="row">Datum<input type="date" value={log.date} onChange={(e) => e.target.value && setLog({ ...log, date: e.target.value })} /></label>
      <label className="row">Dauer (Min.)<input type="number" min={1} value={log.durationMin} onChange={(e) => setLog({ ...log, durationMin: num(e.target.value) })} /></label>
      <textarea placeholder="Notizen zum Training" value={log.notes} onChange={(e) => setLog({ ...log, notes: e.target.value })} /></div>
    <div className="chips"><button className="btn on" onClick={async () => { await put('sessions', log); nav('/kalender'); }}>{exists ? 'Änderungen speichern' : 'Training abschließen'}</button>
      {exists && <button className="btn danger" onClick={async () => { await remove('sessions', log.id); nav('/kalender'); }}>Als nicht erledigt markieren</button>}</div></section>;
}
