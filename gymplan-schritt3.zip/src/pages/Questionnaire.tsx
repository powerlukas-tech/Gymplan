import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { QS } from '../core/questionnaire';
import { generatePlan } from '../core/planner';
import { Answers } from '../core/types';
import { put } from '../db/db';
export default function Questionnaire() {
  const nav = useNavigate();
  const [a, setA] = useState<Answers>({}); const [i, setI] = useState(0);
  const vis = QS.filter((q) => !q.when || q.when(a));
  const idx = Math.min(i, vis.length - 1), q = vis[idx], v = a[q.id];
  const sel = (k: string) => {
    if (q.type === 'single') return setA({ ...a, [q.id]: k });
    const cur = Array.isArray(v) ? v : [];
    setA({ ...a, [q.id]: cur.includes(k) ? cur.filter((x) => x !== k) : [...cur, k] });
  };
  const on = (k: string) => (Array.isArray(v) ? v.includes(k) : v === k);
  const valid = q.type === 'single' ? !!v : q.optional || (Array.isArray(v) && v.length > 0);
  const last = idx === vis.length - 1;
  const finish = async () => { await put('plans', generatePlan(a)); nav('/plan'); };
  return <section><p className="muted">Frage {idx + 1} von {vis.length}</p>
    <div className="bar"><div style={{ width: ((idx + 1) / vis.length) * 100 + '%' }} /></div>
    <div className="card"><h2>{q.title}</h2>{q.hint && <p className="muted">{q.hint}</p>}
      <div className="chips col">{q.opts.map(([k, l]) => <button key={k} className={'chip' + (on(k) ? ' on' : '')} onClick={() => sel(k)}>{l}</button>)}</div></div>
    <div className="chips">
      <button className="btn" disabled={idx === 0} onClick={() => setI(idx - 1)}>Zurück</button>
      {last ? <button className="btn on" disabled={!valid} onClick={finish}>Plan erstellen</button>
        : <button className="btn on" disabled={!valid} onClick={() => setI(idx + 1)}>Weiter</button>}</div></section>;
}
