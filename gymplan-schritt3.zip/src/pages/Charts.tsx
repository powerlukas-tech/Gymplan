type P = { l: string; v: number };
export function Bars({ data }: { data: P[] }) {
  const max = Math.max(1, ...data.map((d) => d.v)), w = 320, h = 110, bw = w / data.length;
  return <svg viewBox={`0 0 ${w} ${h + 22}`} className="chart" role="img" aria-label="Balkendiagramm">{data.map((d, i) => { const bh = (d.v / max) * h; return <g key={i}>
    <rect x={i * bw + 6} y={h - bh} width={bw - 12} height={bh} rx={5} fill="var(--accent)" />
    <text x={i * bw + bw / 2} y={h - bh - 4} textAnchor="middle" fontSize="10" fill="var(--text)">{d.v || ''}</text>
    <text x={i * bw + bw / 2} y={h + 15} textAnchor="middle" fontSize="9" fill="var(--muted)">{d.l}</text></g>; })}</svg>;
}
export function Line({ data }: { data: P[] }) {
  const w = 320, h = 110, max = Math.max(1, ...data.map((d) => d.v)), min = Math.min(...data.map((d) => d.v));
  const x = (i: number) => 14 + (data.length === 1 ? (w - 28) / 2 : (i * (w - 28)) / (data.length - 1));
  const y = (v: number) => 10 + (h - 20) * (1 - (max === min ? 0.5 : (v - min) / (max - min)));
  return <svg viewBox={`0 0 ${w} ${h + 22}`} className="chart" role="img" aria-label="Liniendiagramm">
    <polyline points={data.map((d, i) => `${x(i)},${y(d.v)}`).join(' ')} fill="none" stroke="var(--accent)" strokeWidth="2.5" />
    {data.map((d, i) => <g key={i}><circle cx={x(i)} cy={y(d.v)} r="4" fill="var(--accent)" /><text x={x(i)} y={y(d.v) - 8} textAnchor="middle" fontSize="10" fill="var(--text)">{d.v}</text>
      {(i === 0 || i === data.length - 1) && <text x={x(i)} y={h + 16} textAnchor="middle" fontSize="9" fill="var(--muted)">{d.l}</text>}</g>)}</svg>;
}
