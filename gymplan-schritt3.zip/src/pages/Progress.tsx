import { useState } from 'react';
import { Link } from 'react-router-dom';
import { addDays, fmt, key, weekday } from '../core/schedule';
import { Goal, LOCAL_USER_ID } from '../core/types';
import { put } from '../db/db';
import { useTraining } from '../state/useTraining';
import { Bars, Line } from './Charts';
export default function Progress() {
  const { d, load } = useTraining(); const [ex, setEx] = useState('');
  const [g, setG] = useState({ title: '', current: '', target: '', unit: '' });
  if (!d) return null;
  const { logs, goals } = d, today = key(new Date()), sorted = [...logs].sort((a, b) => a.date.localeCompare(b.date));
  const ws = addDays(today, -weekday(today));
  const weeks = Array.from({ length: 8 }, (_, i) => addDays(ws, (i - 7) * 7)).map((w) => ({ l: w.slice(8) + '.' + w.slice(5, 7), v: logs.filter((x) => x.date >= w && x.date < addDays(w, 7)).length }));
  const sets = logs.reduce((s, l) => s + l.entries.reduce((a, e) => a + e.sets.length, 0), 0);
  const names = [...new Map(logs.flatMap((l) => l.entries).map((e) => [e.exId, e.name])).entries()];
  const exId = ex || names[0]?.[0] || '';
  const heavy = sorted.some((l) => l.entries.some((e) => e.exId === exId && e.sets.some((s) => s.weight > 0)));
  const pts = sorted.flatMap((l) => { const e = l.entries.find((x) => x.exId === exId); return e ? [{ l: l.date.slice(8) + '.' + l.date.slice(5, 7), v: Math.max(...e.sets.map((s) => (heavy ? s.weight : s.reps))) }] : []; });
  const saveGoals = async (items: Goal[]) => { await put('settings', { id: 'goals', user_id: LOCAL_USER_ID, items } as any); await load(); };
  const addGoal = async () => { if (!g.title.trim() || !+g.target) return; await saveGoals([...goals, { id: crypto.randomUUID(), title: g.title.trim(), current: +g.current || 0, target: +g.target, unit: g.unit }]); setG({ title: '', current: '', target: '', unit: '' }); };
  return <section><h1>Fortschritt</h1>
    <div className="stats">{[[logs.length, 'Einheiten'], [logs.reduce((s, l) => s + l.durationMin, 0), 'Minuten'], [sets, 'Sätze']].map(([v, l]) => <div className="card stat" key={l as string}><b>{v}</b><span className="muted">{l}</span></div>)}</div>
    <div className="card"><h2>Einheiten pro Woche</h2><Bars data={weeks} />{!logs.length && <p className="muted">Sobald du Training abhakst, erscheinen hier deine Daten.</p>}</div>
    <div className="card"><h2>Übungsverlauf</h2>{names.length ? <>
      <select value={exId} onChange={(e) => setEx(e.target.value)}>{names.map(([id, n]) => <option key={id} value={id}>{n}</option>)}</select>
      <p className="muted">Bester Satz je Einheit ({heavy ? 'Gewicht in kg' : 'Wiederholungen bzw. Sekunden'})</p><Line data={pts} /></> : <p className="muted">Noch keine Übungen protokolliert.</p>}</div>
    <div className="card"><h2>Persönliche Ziele</h2>
      {goals.map((x) => <div key={x.id} className="occ"><b>{x.title}</b><div className="bar"><div style={{ width: Math.min(100, (x.current / x.target) * 100) + '%' }} /></div>
        <div className="row"><label>Aktuell <input type="number" value={x.current} onChange={(e) => saveGoals(goals.map((y) => y.id === x.id ? { ...y, current: +e.target.value || 0 } : y))} /></label>
          <span className="muted">Ziel: {x.target} {x.unit}</span><button className="btn danger" onClick={() => confirm('Ziel löschen?') && saveGoals(goals.filter((y) => y.id !== x.id))}>Löschen</button></div></div>)}
      <div className="grid3"><input placeholder="Ziel, z. B. Klimmzüge" value={g.title} onChange={(e) => setG({ ...g, title: e.target.value })} /><input type="number" placeholder="Aktuell" value={g.current} onChange={(e) => setG({ ...g, current: e.target.value })} /><input type="number" placeholder="Zielwert" value={g.target} onChange={(e) => setG({ ...g, target: e.target.value })} /></div>
      <div className="chips"><input placeholder="Einheit (z. B. Wdh.)" value={g.unit} onChange={(e) => setG({ ...g, unit: e.target.value })} /><button className="btn on" onClick={addGoal}>Ziel speichern</button></div></div>
    <div className="card"><h2>Trainingshistorie</h2>{!sorted.length && <p className="muted">Noch keine Einheiten.</p>}
      {[...sorted].reverse().map((l) => <details key={l.id} className="ex"><summary>{fmt(l.date)} · {l.label} <span className="muted">{l.durationMin} Min.</span></summary>
        {l.entries.map((e, i) => <p key={i}><b>{e.name}</b>: {e.sets.map((s) => (s.weight ? `${s.reps}×${s.weight} kg` : s.reps)).join(', ')}</p>)}
        {l.notes && <p className="muted">Notiz: {l.notes}</p>}<Link to={`/training/${l.origDate}/${l.dayId}`}>Bearbeiten</Link></details>)}</div></section>;
}
