import { useState } from 'react';
import { Link } from 'react-router-dom';
import { addDays, defaultLog, fmt, key, occOn, parse, weekday } from '../core/schedule';
import { LOCAL_USER_ID } from '../core/types';
import { put, remove } from '../db/db';
import { useTraining } from '../state/useTraining';
export default function Calendar() {
  const { d, load } = useTraining(); const today = key(new Date());
  const [cur, setCur] = useState(() => { const t = new Date(); return new Date(t.getFullYear(), t.getMonth(), 1); });
  const [sel, setSel] = useState(today);
  if (!d) return null;
  if (!d.plan) return <section><h1>Kalender</h1><div className="card"><p>Ohne Trainingsplan gibt es noch keine Termine.</p><Link className="btn" to="/fragebogen">Fragebogen starten</Link></div></section>;
  const { plan, logs, moves } = d;
  const occ = (k: string) => occOn(plan, moves, logs, k);
  const first = key(cur), pad = weekday(first), n = new Date(cur.getFullYear(), cur.getMonth() + 1, 0).getDate();
  const cells = [...Array(pad).fill(null), ...Array.from({ length: n }, (_, i) => addDays(first, i))] as (string | null)[];
  const status = (k: string) => { const o = occ(k); if (!o.length) return 'rest'; if (o.every((x) => x.log)) return 'done'; return k < today ? 'missed' : 'plan'; };
  const sOcc = occ(sel), matched = new Set(sOcc.map((o) => o.log?.id));
  const extra = logs.filter((l) => l.date === sel && !matched.has(l.id));
  const act = async (f: () => Promise<unknown>) => { await f(); await load(); };
  return <section><h1>Kalender</h1>
    <div className="row"><button className="btn" onClick={() => setCur(new Date(cur.getFullYear(), cur.getMonth() - 1, 1))}>Zurück</button>
      <b>{cur.toLocaleDateString('de-DE', { month: 'long', year: 'numeric' })}</b><button className="btn" onClick={() => setCur(new Date(cur.getFullYear(), cur.getMonth() + 1, 1))}>Weiter</button></div>
    <div className="cal">{['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'].map((w) => <span key={w} className="muted">{w}</span>)}
      {cells.map((k, i) => k ? <button key={k} className={`day ${status(k)}${k === sel ? ' sel' : ''}${k === today ? ' today' : ''}`} onClick={() => setSel(k)} aria-label={fmt(k)}>{+k.slice(8)}</button> : <span key={'p' + i} />)}</div>
    <p className="muted legend">Gefüllt: erledigt · Rahmen: geplant · Gestrichelt: verpasst · Grau: Ruhetag</p>
    <div className="card"><h2>{fmt(sel)}</h2>
      {!sOcc.length && !extra.length && <p>Ruhetag. Erholung gehört zum Training.</p>}
      {sOcc.map((o) => <div key={o.day.id + o.orig} className="occ"><b>{o.day.label}</b> {o.moved && <span className="muted">(verschoben von {fmt(o.orig)})</span>}
        <p className="muted">{o.day.exercises.length} Übungen · {o.log ? `erledigt, ${o.log.durationMin} Min.` : sel < today ? 'nicht erledigt' : 'geplant'}{o.log?.notes ? ` · Notiz: ${o.log.notes}` : ''}</p>
        <div className="chips"><Link className="btn" to={`/training/${o.orig}/${o.day.id}`}>{o.log ? 'Ansehen / Bearbeiten' : 'Training starten'}</Link>
          {!o.log && <button className="btn" onClick={() => act(() => put('sessions', defaultLog(o, sel <= today ? sel : today)))}>Abhaken</button>}
          {o.log && <button className="btn danger" onClick={() => act(() => remove('sessions', o.log!.id))}>Abhaken rückgängig</button>}</div>
        {!o.log && <label className="row">Verschieben auf<input type="date" value={sel} onChange={(e) => { const to = e.target.value; if (!to || to === sel) return;
          act(async () => { const id = `move_${o.orig}_${o.day.id}`; if (to === o.orig) await remove('sessions', id); else await put('sessions', { id, kind: 'move', user_id: LOCAL_USER_ID, from: o.orig, to, dayId: o.day.id }); setSel(to); setCur(parse(to.slice(0, 8) + '01')); }); }} /></label>}</div>)}
      {extra.map((l) => <p key={l.id}>Erledigt: {l.label} ({l.durationMin} Min.) · <Link to={`/training/${l.origDate}/${l.dayId}`}>ansehen</Link></p>)}</div></section>;
}
