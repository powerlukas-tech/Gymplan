import { NavLink, Route, Routes } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import Calendar from './pages/Calendar';
import Progress from './pages/Progress';
import Training from './pages/Training';
import Settings from './pages/Settings';
import Questionnaire from './pages/Questionnaire';
import PlanPage from './pages/Plan';
import Exercises from './pages/Exercises';
const nav = [['/', 'Dashboard'], ['/plan', 'Plan'], ['/kalender', 'Kalender'], ['/fortschritt', 'Fortschritt'], ['/uebungen', 'Übungen'], ['/profil', 'Profil']] as const;
export default function App() {
  return (<div className="shell">
    <main><Routes>
      <Route path="/" element={<Dashboard />} />
      <Route path="/plan" element={<PlanPage />} />
      <Route path="/kalender" element={<Calendar />} />
      <Route path="/fortschritt" element={<Progress />} />
      <Route path="/uebungen" element={<Exercises />} />
      <Route path="/fragebogen" element={<Questionnaire />} />
      <Route path="/training/:orig/:dayId" element={<Training />} />
      <Route path="/profil" element={<Settings />} />
    </Routes></main>
    <nav>{nav.map(([to, l]) => <NavLink key={to} to={to} end={to === '/'}>{l}</NavLink>)}</nav>
  </div>);
}
