import { LOCAL_USER_ID } from '../core/types';
const NAME = 'gymplan', VERSION = 1;
export const STORES = ['settings', 'plans', 'sessions', 'backups'] as const;
export type StoreName = (typeof STORES)[number];
let dbp: Promise<IDBDatabase> | null = null;
function open(): Promise<IDBDatabase> {
  return (dbp ??= new Promise((res, rej) => {
    const r = indexedDB.open(NAME, VERSION);
    r.onupgradeneeded = () => { for (const s of STORES) if (!r.result.objectStoreNames.contains(s)) r.result.createObjectStore(s, { keyPath: 'id' }); };
    r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
  }));
}
async function run<T>(s: StoreName, mode: IDBTransactionMode, fn: (st: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const db = await open();
  return new Promise((res, rej) => { const q = fn(db.transaction(s, mode).objectStore(s)); q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error); });
}
export const getAll = <T,>(s: StoreName) => run<T[]>(s, 'readonly', (st) => st.getAll() as IDBRequest<T[]>);
export const getOne = <T,>(s: StoreName, id: string) => run<T | undefined>(s, 'readonly', (st) => st.get(id));
export const put = (s: StoreName, v: { id: string }) => run(s, 'readwrite', (st) => st.put(v));
export const remove = (s: StoreName, id: string) => run(s, 'readwrite', (st) => st.delete(id));
export const clearStore = (s: StoreName) => run(s, 'readwrite', (st) => st.clear());
export interface Dump { app: 'GYMPLAN'; version: 1; user_id: string; exportedAt: string; data: Partial<Record<StoreName, { id: string }[]>>; }
export async function exportAll(): Promise<Dump> {
  const data: Dump['data'] = {};
  for (const s of STORES) if (s !== 'backups') data[s] = await getAll(s);
  return { app: 'GYMPLAN', version: 1, user_id: LOCAL_USER_ID, exportedAt: new Date().toISOString(), data };
}
export function validateDump(d: any): d is Dump {
  return !!d && d.app === 'GYMPLAN' && d.version === 1 && typeof d.data === 'object' && d.data !== null &&
    Object.entries(d.data).every(([k, v]) => (STORES as readonly string[]).includes(k) && Array.isArray(v) && v.every((x: any) => x && typeof x.id === 'string'));
}
export async function importAll(d: Dump) {
  for (const s of STORES) if (s !== 'backups' && d.data[s]) { await clearStore(s); for (const v of d.data[s]!) await put(s, v); }
}
export async function createBackup() { const dump = await exportAll(); await put('backups', { id: 'latest', ...dump }); return dump.exportedAt; }
export async function restoreBackup(): Promise<boolean> {
  const b = await getOne<any>('backups', 'latest');
  if (!b || !validateDump(b)) return false;
  await importAll(b); return true;
}
export async function resetAll() { for (const s of STORES) await clearStore(s); }
